#ifndef CALCULATE_DISTANCE
#define CALCULATE_DISTANCE

#ifdef __cplusplus
extern "C"
{
#endif

#define PI                      3.1415926
#define EARTH_RADIUS            6378.137        //地球近似半径
#define SERVER_IP				"192.168.1.3"	//A点作为服务器端
#define CLIENT_IP				"192.168.1.5"	//C点作为客户端

typedef struct distance 
{
	int distance_isvalid;
	float distance_data;
}distance;

extern int find_position(float *lat1, float *lng1 , float *lat2, float *lng2);  //在neighbor链表中查找源和目标节点经纬度信息；
extern float radian(float d);
extern void* get_distance(void *para);

#ifdef __cplusplus
}
#endif

#endif
