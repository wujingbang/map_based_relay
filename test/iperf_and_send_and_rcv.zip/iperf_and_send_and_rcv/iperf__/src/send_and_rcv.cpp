 
#include <stdio.h>  

#include <sys/socket.h> 

#include <unistd.h>  

#include <sys/types.h>

#include <netdb.h>  

#include <netinet/in.h> 

#include <arpa/inet.h> 

#include <string.h>  

#include <stdint.h>

#include <sys/mman.h>
   
#include <sys/stat.h>  

#include <fcntl.h>

#include <stdlib.h>

#include <linux/netlink.h>

#include <errno.h>
 
#include <signal.h>   
 
#include <sys/time.h> 

#include <semaphore.h>

#include <time.h>

#include <pthread.h>

#include <sys/ioctl.h>

#include <net/if.h>

#include "geohash.h"

#include "send_and_rcv.h"

#include "Ublox.h"

//rcv function

extern neighbor_list *ner_list;

extern char send_neigh_ip[30];

extern Ublox m8_Gps;

extern struct timeval keep_time;

neighbor_table  *neigh_data;

volatile  uint8_t   *neigh_status;

uint32_t     *neigh_count;

struct itimerval tick; 

pthread_mutex_t work_mutex;

void* get_buffer_entry()
{

    int g_fd = -1;

    void *g_pBuffer = NULL;

    if (NULL != g_pBuffer)
    {

        return NULL;
    }

    if (g_fd < 0)
    {
        g_fd = open("/dev/mbr_neighbor_mem", O_RDWR);

        if (0 > g_fd)
        {
            printf("Error : getMemMsgBuf() open /dev/mbr_neighbor_mem failed \n");

            return NULL;
        }
    }

    g_pBuffer = mmap(NULL, 4096 * 4,PROT_READ|PROT_WRITE,MAP_SHARED, g_fd,0 );

    if( g_pBuffer == MAP_FAILED ) 
    {
        printf("Error : getMemMsgBuf() fail mmap!\n");

    }
    return g_pBuffer;
}

void list_copyto_ner()
{
    int i;

    neighbor_list *indx = ner_list->next;
    
    neighbor_table  *entry = neigh_data;
    
    int count=0;  

    *neigh_status = 1;

    while(indx != NULL)
    {
        entry->ip = indx->ip;

        for(i = 0; i < 6; ++i)

            entry->mac[i] = indx->mac[i];

        entry->geoHash = indx->geoHash;

        //entry->direction = indx->direction;

        entry->direction = 0;

        ++entry;

        ++count;

        indx = indx->next;
    } 

    *neigh_count = count;

    *neigh_status = 0;

}

void add_list(struct neighbor* temp)
{
    pthread_mutex_lock(&work_mutex);

    int i,flag=0;

    neighbor_list *tail,*pre;

    neighbor_table  *entry = neigh_data;

    if(ner_list == NULL)
    {
        if((ner_list = (neighbor_list*)malloc(sizeof(neighbor_list))) == NULL)
        {
            printf("malloc error!!\n");

            exit(1);
        }
        ner_list->next = NULL;

        flag = 1;
    }

    pre = ner_list;

    tail = ner_list->next;

    while(1)
    {

        if(tail == NULL || tail->ip == temp->ip)

            break;
        else
            {
                pre = tail;

                tail = tail->next;

            }
    }

    if(tail == NULL)
    {

        if((tail = (neighbor_list*)malloc(sizeof(neighbor_list))) == NULL)
        {
            printf("malloc error!!\n");

            exit(1);
        }
        tail->ip = temp->ip;

        for(i = 0; i < 6; ++i)  

            tail->mac[i] = temp->mac[i];

        tail->latitude = temp->latitude;

        tail->longitude = temp->longitude;

        tail->geoHash = temp->geoHash;

        tail->direction = temp->direction;

        gettimeofday(&(tail->arrive), NULL);

        tail->next = NULL;

        pre->next = tail;
    }

    else
    {
        
        if(tail == ner_list->next)

            flag =1;

        pre->next = pre->next->next;

        tail->latitude = temp->latitude;

        tail->longitude = temp->longitude;

        tail->geoHash = temp->geoHash;

        tail->direction = temp->direction;

        gettimeofday(&(tail->arrive), NULL);

        tail->next = NULL;

        while(pre->next != NULL)

            pre = pre->next;

        pre->next = tail;
    }

    list_copyto_ner();

    if(flag == 1)
    {
        tail = ner_list->next;

        tick.it_value.tv_sec = keep_time.tv_sec;   
  
        tick.it_value.tv_usec = keep_time.tv_usec;  

        tick.it_interval.tv_sec = 0;  
  
        tick.it_interval.tv_usec = 0; 
  
        int res = setitimer(ITIMER_REAL, &tick, NULL);  
  
        if (res) 
        {  
  
            printf("Set timer failed!!/n");  
        }  
    }

    pthread_mutex_unlock(&work_mutex);
}

void update_neighbor(int num)
{

    pthread_mutex_lock(&work_mutex);

    int i;
    
    neighbor_list *indx,*pre;
    
    neighbor_table  *entry = neigh_data;

    int count=0;

    if(ner_list->next == NULL)

        return ;

    indx = ner_list->next;

    long long time_front , time_now;

    time_front = (long long)indx->arrive.tv_sec * 1000000 + (long long)indx->arrive.tv_usec;

    ner_list->next = indx->next;

    free(indx);

    list_copyto_ner();

    indx = ner_list->next;

    if(indx != NULL)
    {
        time_now = (long long)indx->arrive.tv_sec * 1000000 + (long long)indx->arrive.tv_usec;

        tick.it_value.tv_sec = (time_now - time_front) / 1000000;   
  
        tick.it_value.tv_usec = (time_now - time_front) % 1000000;  

        tick.it_interval.tv_sec = 0;  
  
        tick.it_interval.tv_usec = 0; 
  
        int res = setitimer(ITIMER_REAL, &tick, NULL);  
  
        if (res) 
        {  
  
            printf("Set timer failed!!/n");  
        }  
    }
    
    pthread_mutex_unlock(&work_mutex);
}

void* rcv_msg(void *arg)
{
    int i;

    FILE *fp=fopen("./neighbor_data","a+");

    if(fp == NULL)

    {
        printf("open file error!\n");
        exit(1);
    }

    setvbuf(stdout, NULL, _IONBF, 0);

    fflush(stdout);   

    // 绑定地址  
    struct sockaddr_in serv_addr; 

    bzero(&serv_addr, sizeof(struct sockaddr_in));

    serv_addr.sin_family = AF_INET;

    serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);

    serv_addr.sin_port = htons(NEIGHRCVPORT);  

    int sock = -1;

    if ((sock = socket(AF_INET, SOCK_DGRAM, 0)) == -1)   
    {     
        printf("%s\n","socket error!");
  
        return 0;  
    }     

    const int opt = 1; 

    //设置该套接字为广播类型，

    int nb = 0;  

    nb = setsockopt(sock, SOL_SOCKET, SO_BROADCAST, (char *)&opt, sizeof(opt));  
    if(nb == -1)  
    {  
        printf("%s\n","set socket error...");
  
        return 0;  
    }  

    if(bind(sock,(struct sockaddr *)&(serv_addr), sizeof(struct sockaddr_in)) == -1)   
    {     
        printf("%s\n","bind error...");
         
        return 0;  
    }  

    int len = sizeof(struct sockaddr_in); 

    char smsg[PACKETSIZE] = {0};  

    neighbor_message *temp;

    while(1)  
    {  
        //从广播地址接受消息  

        int ret=recvfrom(sock, smsg, PACKETSIZE, 0, NULL, NULL); 

        if(ret<=0)  
        {  
            printf("%s\n","read error....");

        }  
        else  
        {     
            temp = (neighbor_message *)smsg;

            fprintf(fp,"[%hhd_%hhd_%hhd_%hd] %x %f %f %lld %ld\n",m8_Gps.datetime.hours,m8_Gps.datetime.minutes,m8_Gps.datetime.seconds,m8_Gps.datetime.millis,temp->ip,temp->latitude,temp->longitude,temp->geoHash,temp->direction);

            add_list(temp);

            //printf("%x ", temp->ip);  

            //for(i=0; i<6; ++i)

            //printf("%x\n",temp->mac[i]);
  
        } 
    } 

    fclose(fp);
}
        
void* neighbor_rcv(void *arg)

{  
    pthread_t a_thread;

    void *thread_result;

    void *g_pBuffer = NULL;

    g_pBuffer = get_buffer_entry();

    neigh_status = (uint8_t*)((uint8_t*)g_pBuffer + NEIGH_STATUS_OFFSET);

    *neigh_status = 0;

    neigh_count = (uint32_t*)((uint8_t*)g_pBuffer + NEIGH_COUNT_OFFSET);

    *neigh_count = 0;

    neigh_data = (neighbor_table*)((uint8_t*)g_pBuffer + NEIGH_DATA_OFFSET);

    signal(SIGALRM, update_neighbor);

    memset(&tick, 0, sizeof(tick)); 

    int res = pthread_mutex_init(&work_mutex,NULL); 

    if (res != 0) 
    {
        perror("Mutex initialization failed");

        exit(1);
    }

    res = pthread_create(&a_thread, NULL, rcv_msg, NULL); 

    if (res != 0) 
    {
        perror("Thread creation failed");

        exit(1);
    }


    res = pthread_join(a_thread, &thread_result);

    if (res != 0) 
    {
        perror("Thread join failed");

        exit(1);
    }

    pthread_mutex_destroy(&work_mutex); 

    return 0;  
}





//send function
int  GetLocalMac(struct ifreq *ifr_mac)  
{  
    int sock;  
            
    sock = socket( AF_INET, SOCK_STREAM, 0 ); 

    if( sock == -1)  
    {  
        perror("create socket falise...mac/n");  

        return 0;  
    }  
      
    memset(ifr_mac,0,sizeof(*ifr_mac));   

    strncpy(ifr_mac->ifr_name, NET, sizeof(ifr_mac->ifr_name)-1);     
  
    if( (ioctl( sock, SIOCGIFHWADDR, ifr_mac)) < 0)  
    {  
        printf("ioctl error/n"); 

        return 0;  
    }    
            
    close( sock );  

    return 0;  
}

int  GetLocalip(struct ifreq *ifr_ip)  
{  
    int sock;  
            
    sock = socket( AF_INET, SOCK_STREAM, 0 ); 

    if( sock == -1)  
    {  
        perror("create socket falise...ip/n");  

        return 0;  
    }  
      
    memset(ifr_ip,0,sizeof(*ifr_ip));   

    strncpy(ifr_ip->ifr_name, NET, sizeof(ifr_ip->ifr_name)-1);     
  
    if( (ioctl( sock, SIOCGIFADDR, ifr_ip)) < 0)  
    {  
        printf("ioctl error/n"); 

        return 0;  
    }    
            
    close( sock );  

    return 0;  
}

void* neighbor_send(void *avg)
{
  FILE *fp;

  Ublox *m8_Gps = (Ublox*)avg;

  neighbor_message *temp;

  struct ifreq ifr_mac, ifr_ip;

    setvbuf(stdout, NULL, _IONBF, 0);  

  fflush(stdout);   

  struct sockaddr_in addrfrom; 

  bzero(&addrfrom, sizeof(struct sockaddr_in)); 

  addrfrom.sin_family=AF_INET; 

  addrfrom.sin_addr.s_addr=inet_addr(send_neigh_ip);

  addrfrom.sin_port=htons(NEIGHSENDPORT);

    int sock = -1;  

    if ((sock = socket(AF_INET, SOCK_DGRAM, 0)) == -1)   
    {     
         printf("%s\n","socket error");

        return 0;  
    }     

    const int opt = 1;  

    //设置该套接字为广播类型， 

    int nb = 0; 

    nb = setsockopt(sock, SOL_SOCKET, SO_BROADCAST, (char *)&opt, sizeof(opt));  

    if(nb == -1)  
    {  
         printf("%s\n","set socket error...");
  
         return 0;  
    }  

    if(bind(sock,(struct sockaddr *)&(addrfrom), sizeof(struct sockaddr_in)) == -1)   
    {     
        printf("%s\n","bind error...");
         
        return 0;  
    }

    struct sockaddr_in addrto; 

    bzero(&addrto, sizeof(struct sockaddr_in)); 

    addrto.sin_family=AF_INET; 

    addrto.sin_addr.s_addr=htonl(INADDR_BROADCAST);

    addrto.sin_port=htons(NEIGHRCVPORT);

    int nlen=sizeof(addrto);  

    //从广播地址发送消息  

    char smsg[PACKETSIZE];

    temp = (struct neighbor*)smsg;

    GetLocalMac(&ifr_mac);

      GetLocalip(&ifr_ip);

    float latitude, longitude;

    GeoHashBits hash;

    GeoHashRange lat_range={40.15929, 39.74732}, lon_range={ 116.73407, 116.16677};
    
    temp->ip = ((struct sockaddr_in *)&(ifr_ip.ifr_addr))->sin_addr.s_addr;

    temp->mac[0] = (unsigned char)ifr_mac.ifr_hwaddr.sa_data[0];
    temp->mac[1] = (unsigned char)ifr_mac.ifr_hwaddr.sa_data[1];
    temp->mac[2] = (unsigned char)ifr_mac.ifr_hwaddr.sa_data[2]; 
    temp->mac[3] = (unsigned char)ifr_mac.ifr_hwaddr.sa_data[3];  
    temp->mac[4] = (unsigned char)ifr_mac.ifr_hwaddr.sa_data[4];  
    temp->mac[5] = (unsigned char)ifr_mac.ifr_hwaddr.sa_data[5];

    while(1)
    {

      latitude = m8_Gps->latitude;

      longitude = m8_Gps->longitude;

          geohash_fast_encode(lat_range, lon_range, latitude, longitude, 12, &hash);

      temp->latitude = m8_Gps->latitude;

      temp->longitude = m8_Gps->longitude;

          temp->direction = m8_Gps->course;

      temp->geoHash = hash.bits;

      fp=fopen("/sys/kernel/debug/mbr/geohash","w");

      if(fp==NULL)
      {
        printf("open file error!\n");

        exit(1);
      }
      fprintf(fp,"%lld\n",hash.bits);

      fclose(fp);
    
      int ret=sendto(sock, smsg, PACKETSIZE, 0, (struct sockaddr*)&addrto, nlen);  
    
      if(ret<0)  
      {  
        printf("%s\n","send error...."); 
      }  
      else  
      {         
        //printf("%s\n","ok !!!");    
      }
      usleep(100 * 1000);
    }

  /*printf("%x-%x-%x-%x-%x-%x\n",temp->mac[0],temp->mac[1],temp->mac[2],temp->mac[3],temp->mac[4],temp->mac[5]);
  printf("%x\n",temp->ip);
  printf("%lld\n",temp->geoHash);
  printf("%x\n",inet_addr("10.211.55.6"));*/
    
  close(sock);
  return 0;
}
