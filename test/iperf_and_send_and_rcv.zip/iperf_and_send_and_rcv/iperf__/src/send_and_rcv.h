
#ifndef SEND_AND_RCV
#define SEND_AND_RCV

#include <stdint.h>
#include <sys/time.h>

#define NEIGH_STATUS_OFFSET 0
#define NEIGH_COUNT_OFFSET  1
#define NEIGH_DATA_OFFSET   5

#define NEIGHSENDPORT 6000
#define NEIGHRCVPORT 6001

#define PACKETSIZE 40

#define NET "wlp1s0"   //   邻居信息中发送的是wlp1s0网卡的ip和mac地址；

typedef struct neighbor{

uint32_t ip;

uint8_t mac[6];

float latitude,longitude;

uint64_t geoHash;

uint32_t direction;

}neighbor_message;   //邻居信息的数据结构；

typedef struct neighbor_table_ {

    uint32_t ip;

    uint8_t mac[6];

    uint64_t geoHash;

    int direction;
    
    int     isvalid;

}neighbor_table;    //邻居表的表项数据结构；

typedef struct neighbor_list {

    uint32_t ip;

    uint8_t mac[6];

    float latitude,longitude;

    uint64_t geoHash;

    int direction;

    struct timeval arrive;

    struct neighbor_list *next;

}neighbor_list;  //邻居链表节点的数据结构；

void* neighbor_rcv(void *arg);

void* neighbor_send(void *avg);

#endif