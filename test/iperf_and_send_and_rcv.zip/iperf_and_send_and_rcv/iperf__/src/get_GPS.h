
#ifndef GET_GPS
#define GET_GPS

#define MAX_PLATFORM_MODEL_SN 3

#define SIZE_PER_PLATFORM 44

void* gpsdata_decode_loop(void *avg);

#endif