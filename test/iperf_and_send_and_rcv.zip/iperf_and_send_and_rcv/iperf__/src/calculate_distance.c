#include <math.h>
#include <unistd.h>
#include <string.h>
#include <arpa/inet.h>
#include "send_and_rcv.h"
#include "calculate_distance.h"

extern neighbor_list *ner_list; //邻居链表的数据结构，用于更新邻居表和计算距离等操作；
uint32_t server_ip,client_ip;

// 求弧度
float radian(float d)
{
    return d * PI / 180.0;   //角度1˚ = π / 180
}

int find_position(float *lat1, float *lng1 , float *lat2, float *lng2)
{
	neighbor_list *indx;
	int valid1=0, valid2=0;
	if(ner_list == NULL)
		return 0;
	indx = ner_list->next;
	while(indx != NULL)
	{
		if(indx->ip == server_ip)
		{
			*lat1 = indx->latitude;
			*lng1 = indx->longitude;
			valid1 = 1;
		}
		if(indx->ip == client_ip)
		{
			*lat2 = indx->latitude;
			*lng2 = indx->longitude;
			valid2 = 1;
		}
		indx = indx->next;
	}
	return valid1*valid2;
}

//计算距离
void* get_distance(void *para)
{
	float lat1,  lng1,  lat2,  lng2;
	distance *temp;
	temp = (distance*)para;
	neighbor_list *indx;
	
	server_ip=(uint32_t)inet_addr(SERVER_IP);
	client_ip=(uint32_t)inet_addr(CLIENT_IP);

	while(1)
	{
		int ret = find_position(&lat1 , &lng1, &lat2 , &lng2);
		if(ret == 0)
		{
			temp->distance_isvalid = 0;
			usleep(500*1000);
			continue;
		}
		temp->distance_isvalid = 1;

		float radLat1 = radian(lat1);
		float radLat2 = radian(lat2);
		float a = radLat1 - radLat2;
		float b = radian(lng1) - radian(lng2);

		float dst = 2 * asin((sqrt(pow(sin(a / 2), 2) + cos(radLat1) * cos(radLat2) * pow(sin(b / 2), 2) )));

    	dst = dst * EARTH_RADIUS;
    	dst= round(dst * 10000) / 10000;
    	
    	temp->distance_data = dst;
    	usleep(500*1000);
	}
}
