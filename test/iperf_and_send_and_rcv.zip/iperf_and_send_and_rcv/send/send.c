#include <stdio.h>
#include <unistd.h>
#include <sys/socket.h>   
#include <sys/types.h>  
#include <netdb.h>  
#include <netinet/in.h>  
#include <arpa/inet.h>  
#include <string.h>  
#include <sys/timeb.h>
#include <sys/ioctl.h>
#include <net/if.h>

#include "i2c-gps.h"
#include "serial-gps.h"
#include "Ublox.h"
#include "geohash.h"

#define NEIGHSENDPORT 6000
#define NEIGHRCVPORT 6001

#define NET  "wlp1s0" 

#define MAX_PLATFORM_MODEL_SN 3
int gps_platform_model_sn = 0;//

bool changeSpeedFlag = 0;
bool changePwrFlag = 0;
bool changeGpsplatformFlag = 0;

unsigned char gps_config_change[] = {

    /* CFG_GNSS: GPS & GLONASS with SBAS */
    0xB5, 0x62, 0x06, 0x3E, 0x34, 0x00, 0x00, 0x00, 0x20,
    0x06, 0x00, 0x08, 0x10, 0x00, 0x01, 0x00, 0x01, 0x01,
    0x01, 0x01, 0x03, 0x00, 0x01, 0x00, 0x01, 0x01, 0x03,
    0x08, 0x10, 0x00, 0x00, 0x00, 0x01, 0x01, 0x04, 0x00,
    0x08, 0x00, 0x00, 0x00, 0x01, 0x01, 0x05, 0x00, 0x03,
    0x00, 0x00, 0x00, 0x01, 0x01, 0x06, 0x08, 0x0E, 0x00,
    0x01, 0x00, 0x01, 0x01, 0x15, 0xED,

    /* CFG_SBAS: MSAS */
    0xB5, 0x62, 0x06, 0x16, 0x08, 0x00, 0x01, 0x03, 0x03,
    0x00, 0x00, 0x02, 0x02, 0x00, 0x2F, 0xC3

};

#define SIZE_PER_PLATFORM 44
unsigned char gps_platform_model_data[] = {
    /* CFG_NAV5: Platform model: 2-Stationary */
    0xB5, 0x62, 0x06, 0x24, 0x24, 0x00, 0xFF, 0xFF, 0x02,
    0x03, 0x00, 0x00, 0x00, 0x00, 0x10, 0x27, 0x00, 0x00,
    0x05, 0x00, 0xFA, 0x00, 0xFA, 0x00, 0x64, 0x00, 0x5E,
    0x01, 0x00, 0x3C, 0x00, 0x00, 0x00, 0x00, 0xC8, 0x00,
    0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x4B, 0xD2,

    /* CFG_NAV5: Platform model: 3-Pedestrian */
    0xB5, 0x62, 0x06, 0x24, 0x24, 0x00, 0xFF, 0xFF, 0x03,
    0x03, 0x00, 0x00, 0x00, 0x00, 0x10, 0x27, 0x00, 0x00,
    0x05, 0x00, 0xFA, 0x00, 0xFA, 0x00, 0x64, 0x00, 0x5E,
    0x01, 0x00, 0x3C, 0x00, 0x00, 0x00, 0x00, 0xC8, 0x00,
    0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x4C, 0xF4,

    /* CFG_NAV5: Platform model: 4-Automotive */
    0xB5, 0x62, 0x06, 0x24, 0x24, 0x00, 0xFF, 0xFF, 0x04,
    0x03, 0x00, 0x00, 0x00, 0x00, 0x10, 0x27, 0x00, 0x00,
    0x05, 0x00, 0xFA, 0x00, 0xFA, 0x00, 0x64, 0x00, 0x5E,
    0x01, 0x00, 0x3C, 0x00, 0x00, 0x00, 0x00, 0xC8, 0x00,
    0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x4D, 0x16,

    /* CFG_NAV5: Platform model: 0-Portable */
    0xB5, 0x62, 0x06, 0x24, 0x24, 0x00, 0xFF, 0xFF, 0x00,
    0x03, 0x00, 0x00, 0x00, 0x00, 0x10, 0x27, 0x00, 0x00,
    0x05, 0x00, 0xFA, 0x00, 0xFA, 0x00, 0x64, 0x00, 0x5E,
    0x01, 0x00, 0x3C, 0x00, 0x00, 0x00, 0x00, 0xC8, 0x00,
    0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x49, 0x8E,

};

struct neighbor {

uint32_t ip;

uint8_t mac[6];

float latitude,longitude;

uint64_t geoHash;

uint32_t direction;

}*temp;

struct ifreq ifr_mac, ifr_ip;

int  GetLocalMac()  
{  
    int sock;  
            
    sock = socket( AF_INET, SOCK_STREAM, 0 ); 

    if( sock == -1)  
    {  
        perror("create socket falise...mac/n");  

        return 0;  
    }  
      
    memset(&ifr_mac,0,sizeof(ifr_mac));   

    strncpy(ifr_mac.ifr_name, NET, sizeof(ifr_mac.ifr_name)-1);     
  
    if( (ioctl( sock, SIOCGIFHWADDR, &ifr_mac)) < 0)  
    {  
        printf("ioctl error/n"); 

        return 0;  
    }    
            
    close( sock );  

    return 0;  
}

int  GetLocalip()  
{  
    int sock;  
            
    sock = socket( AF_INET, SOCK_STREAM, 0 ); 

    if( sock == -1)  
    {  
        perror("create socket falise...ip/n");  

        return 0;  
    }  
      
    memset(&ifr_ip,0,sizeof(ifr_ip));   

    strncpy(ifr_ip.ifr_name, NET, sizeof(ifr_ip.ifr_name)-1);     
  
    if( (ioctl( sock, SIOCGIFADDR, &ifr_ip)) < 0)  
    {  
        printf("ioctl error/n"); 

        return 0;  
    }    
            
    close( sock );  

    return 0;  
}


void* gpsdata_decode_loop(void * parm) 
{
	Ublox *M8_Gps_ = (Ublox*)parm;
	i2cgps gps;
	serialGps gps_serial;
	bool ret;

	if(changeGpsplatformFlag) 
	{
		gps.write_gps_config(gps_platform_model_data + (gps_platform_model_sn * SIZE_PER_PLATFORM), SIZE_PER_PLATFORM);
	} 
	else 
	{
		printf("changeGpsplatformFlag error!\n");
	}

	printf("%d\n",gps.write_gps_config(gps_config_change, sizeof(gps_config_change)));

	int bytesread;

	while(1) 
	{
		bytesread = gps_serial.get_gps_data2buf();
	    if(bytesread < 0)
	    {
	    	printf("gpsdata_decode_loop: bytes<0!\n");
	    	exit(0);
	    }

		for (int i = 0; i < bytesread; i++) 
		{
			M8_Gps_->encode((char)(gps_serial.gpsdata_buf())[i]);

		}

		pthread_testcancel();
	}
}

int main(int argc, char *argv[])
{
  pthread_t gpstid;

	Ublox *m8_Gps = new Ublox();

	int ret = pthread_create(&gpstid, NULL, gpsdata_decode_loop, (void*)m8_Gps);

	setvbuf(stdout, NULL, _IONBF, 0);  

  fflush(stdout);   

  struct sockaddr_in addrfrom; 

  bzero(&addrfrom, sizeof(struct sockaddr_in)); 

  addrfrom.sin_family=AF_INET; 

  addrfrom.sin_addr.s_addr=inet_addr(argv[1]);

  addrfrom.sin_port=htons(NEIGHSENDPORT);

 	int sock = -1;  

  	if ((sock = socket(AF_INET, SOCK_DGRAM, 0)) == -1)   
  	{     
     	 printf("%s\n","socket error");

      	return 0;  
  	}     

  	const int opt = 1;  

  	//设置该套接字为广播类型， 

  	int nb = 0; 

 	nb = setsockopt(sock, SOL_SOCKET, SO_BROADCAST, (char *)&opt, sizeof(opt));  

  	if(nb == -1)  
  	{  
   		 printf("%s\n","set socket error...");
  
   		 return 0;  
  	}  

    if(bind(sock,(struct sockaddr *)&(addrfrom), sizeof(struct sockaddr_in)) == -1)   
    {     
        printf("%s\n","bind error...");
         
        return 0;  
    }

  	struct sockaddr_in addrto; 

  	bzero(&addrto, sizeof(struct sockaddr_in)); 

  	addrto.sin_family=AF_INET; 

  	addrto.sin_addr.s_addr=htonl(INADDR_BROADCAST);

  	addrto.sin_port=htons(NEIGHRCVPORT);

  	int nlen=sizeof(addrto);  

  	//从广播地址发送消息  

  	char smsg[40];

  	temp = (struct neighbor*)smsg;

  	GetLocalMac();

 	GetLocalip();

	float latitude, longitude;

	uint16_t course;

	GeoHashBits hash;
    GeoHashRange lat_range={40.15929, 39.74732}, lon_range={ 116.73407, 116.16677};
    
   	temp->ip = ((struct sockaddr_in *)&(ifr_ip.ifr_addr))->sin_addr.s_addr;

  	temp->mac[0] = (unsigned char)ifr_mac.ifr_hwaddr.sa_data[0];
  	temp->mac[1] = (unsigned char)ifr_mac.ifr_hwaddr.sa_data[1];
  	temp->mac[2] = (unsigned char)ifr_mac.ifr_hwaddr.sa_data[2]; 
  	temp->mac[3] = (unsigned char)ifr_mac.ifr_hwaddr.sa_data[3];  
  	temp->mac[4] = (unsigned char)ifr_mac.ifr_hwaddr.sa_data[4];  
  	temp->mac[5] = (unsigned char)ifr_mac.ifr_hwaddr.sa_data[5];

    while(!m8_Gps->datetime.valid)
    {
      printf("send_tester_loop: waiting for GPS validation\n");
      usleep(500 * 1000);
    }

  	while(1)
  	{
  		longitude = m8_Gps->longitude;

		latitude = m8_Gps->latitude;
	
		course = m8_Gps->course;

		geohash_fast_encode(lat_range, lon_range, latitude, longitude, 12, &hash);

    temp->latitude = latitude;

    temp->longitude = longitude;

		temp->direction = course;

  	temp->geoHash = hash.bits;

    FILE* fp=fopen("/sys/kernel/debug/mbr/geohash","w");
    if(fp==NULL)
    {
        printf("open file error!\n");
        exit(1);
    }
    fprintf(fp,"%lld\n",hash.bits);
    fclose(fp);

    fp=fopen("/home/root/position","w");
    if(fp==NULL)
    {
        printf("open file error!\n");
        exit(1);
    }
    fprintf(fp,"%f,%f\n",latitude,longitude);
    fclose(fp);
    
        int ret=sendto(sock, smsg, 25, 0, (struct sockaddr*)&addrto, nlen);  
    
        if(ret<0)  
        {  
          printf("%s\n","send error...."); 
        }  
        else  
        {         
          //printf("%s\n","ok !!!");    
        }
        usleep(100 * 1000);
	}

  /*printf("%x-%x-%x-%x-%x-%x\n",temp->mac[0],temp->mac[1],temp->mac[2],temp->mac[3],temp->mac[4],temp->mac[5]);
  printf("%x\n",temp->ip);
  printf("%lld\n",temp->geoHash);
  printf("%x\n",inet_addr("10.211.55.6"));*/
    
  close(sock);
  return 0;
}
