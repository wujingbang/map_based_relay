 
#include <stdio.h>  

#include <sys/socket.h> 

#include <unistd.h>  

#include <sys/types.h>

#include <netdb.h>  

#include <netinet/in.h> 

#include <arpa/inet.h> 

#include <string.h>  

#include <stdint.h>

#include <sys/mman.h>
   
#include <sys/stat.h>  

#include <fcntl.h>

#include <stdlib.h>

#include <linux/netlink.h>

#include <errno.h>
 
#include <signal.h>   
 
#include <sys/time.h> 

#include <semaphore.h>

#include <pthread.h>

#define NEIGH_STATUS_OFFSET 0
#define NEIGH_COUNT_OFFSET  1
#define NEIGH_DATA_OFFSET   5

#define NEIGHSENDPORT 6000
#define NEIGHRCVPORT 6001

struct neighbor{

uint32_t ip;

uint8_t mac[6];

float latitude,longitude;

uint64_t geoHash;

uint32_t direction;

}*temp;

typedef struct neighbor_table_ {

    uint32_t ip;

    uint8_t mac[6];

    uint64_t geoHash;

    int direction;
    
    int     isvalid;

}neighbor_table;

typedef struct neighbor_list {

    uint32_t ip;

    uint8_t mac[6];

    float latitude,longitude;

    uint64_t geoHash;

    int direction;

    struct timeval arrive;

    struct neighbor_list *next;

}neighbor_list;

neighbor_list *ner_list = NULL;

neighbor_table  *neigh_data;

uint8_t      *neigh_status;

uint32_t     *neigh_count;

struct itimerval tick; 

struct timeval keep_time;

pthread_mutex_t work_mutex;

void *g_pBuffer = NULL;

int g_fd = -1;

void get_buffer_entry()
{

    if (NULL != g_pBuffer)
    {

        return ;
    }

    if (g_fd < 0)
    {
        g_fd = open("/dev/mbr_neighbor_mem", O_RDWR);

        if (0 > g_fd)
        {
            printf("Error : getMemMsgBuf() open /dev/mbr_neighbor_mem failed \n");

            return ;
        }
    }

    g_pBuffer = mmap(NULL, 4096 * 4,PROT_READ|PROT_WRITE,MAP_SHARED, g_fd,0 );

    if( g_pBuffer == MAP_FAILED ) 
    {
        printf("Error : getMemMsgBuf() fail mmap!\n");

    }
    return ;
}

void list_copyto_ner()
{
    int i;

    neighbor_list *indx = ner_list->next;
    
    neighbor_table  *entry = neigh_data;
    
    int count=0;  

    *neigh_status = 1;

    while(indx != NULL)
    {
        entry->ip = indx->ip;

        for(i = 0; i < 6; ++i)

            entry->mac[i] = indx->mac[i];

        entry->geoHash = indx->geoHash;

        entry->direction = indx->direction;

        ++entry;

        ++count;

        indx = indx->next;
    } 

    *neigh_count = count;

    *neigh_status = 0;

}

void add_list(struct neighbor* temp)
{
    pthread_mutex_lock(&work_mutex);

    int i,flag=0;

    neighbor_list *tail,*pre;

    neighbor_table  *entry = neigh_data;

    if(ner_list == NULL)
    {
        if((ner_list = (neighbor_list*)malloc(sizeof(neighbor_list))) == NULL)
        {
            printf("malloc error!!\n");

            exit(1);
        }
        ner_list->next = NULL;

        flag = 1;
    }

    pre = ner_list;

    tail = ner_list->next;

    while(1)
    {

        if(tail == NULL || tail->ip == temp->ip)

            break;
        else
            {
                pre = tail;

                tail = tail->next;

            }
    }

    if(tail == NULL)
    {

        if((tail = (neighbor_list*)malloc(sizeof(neighbor_list))) == NULL)
        {
            printf("malloc error!!\n");

            exit(1);
        }
        tail->ip = temp->ip;

        for(i = 0; i < 6; ++i)  

            tail->mac[i] = temp->mac[i];

        tail->latitude = temp->latitude;

        tail->longitude = temp->longitude;

        tail->geoHash = temp->geoHash;

        tail->direction = temp->direction;

        gettimeofday(&(tail->arrive), NULL);

        tail->next = NULL;

        pre->next = tail;
    }

    else
    {
        
        if(tail == ner_list->next)

            flag =1;

        pre->next = pre->next->next;

        tail->latitude = temp->latitude;

        tail->longitude = temp->longitude;

        tail->geoHash = temp->geoHash;

        tail->direction = temp->direction;

        gettimeofday(&(tail->arrive), NULL);

        tail->next = NULL;

        while(pre->next != NULL)

            pre = pre->next;

        pre->next = tail;
    }

    list_copyto_ner();

    if(flag == 1)
    {
        tail = ner_list->next;

        tick.it_value.tv_sec = keep_time.tv_sec;   
  
        tick.it_value.tv_usec = keep_time.tv_usec;  

        tick.it_interval.tv_sec = 0;  
  
        tick.it_interval.tv_usec = 0; 
  
        int res = setitimer(ITIMER_REAL, &tick, NULL);  
  
        if (res) 
        {  
  
            printf("Set timer failed!!/n");  
        }  
    }

    pthread_mutex_unlock(&work_mutex);
}

void update_neighbor(int num)
{

    pthread_mutex_lock(&work_mutex);

    int i;
    
    neighbor_list *indx,*pre;
    
    neighbor_table  *entry = neigh_data;

    int count=0;

    if(ner_list->next == NULL)

        return ;

    indx = ner_list->next;

    long long time_front , time_now;

    time_front = (long long)indx->arrive.tv_sec * 1000000 + (long long)indx->arrive.tv_usec;

    ner_list->next = indx->next;

    free(indx);

    list_copyto_ner();

    indx = ner_list->next;

    if(indx != NULL)
    {
        time_now = (long long)indx->arrive.tv_sec * 1000000 + (long long)indx->arrive.tv_usec;

        tick.it_value.tv_sec = (time_now - time_front) / 1000000;   
  
        tick.it_value.tv_usec = (time_now - time_front) % 1000000;  

        tick.it_interval.tv_sec = 0;  
  
        tick.it_interval.tv_usec = 0; 
  
        int res = setitimer(ITIMER_REAL, &tick, NULL);  
  
        if (res) 
        {  
  
            printf("Set timer failed!!/n");  
        }  
    }
    
    pthread_mutex_unlock(&work_mutex);
}

void* rcv_msg(void *arg)
{
    int i;

    setvbuf(stdout, NULL, _IONBF, 0);

    fflush(stdout);   

    // 绑定地址  
    struct sockaddr_in serv_addr; 

    bzero(&serv_addr, sizeof(struct sockaddr_in));

    serv_addr.sin_family = AF_INET;

    serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);

    serv_addr.sin_port = htons(NEIGHRCVPORT);  

    int sock = -1;

    if ((sock = socket(AF_INET, SOCK_DGRAM, 0)) == -1)   
    {     
        printf("%s\n","socket error!");
  
        return 0;  
    }     

    const int opt = 1; 

    //设置该套接字为广播类型，

    int nb = 0;  

    nb = setsockopt(sock, SOL_SOCKET, SO_BROADCAST, (char *)&opt, sizeof(opt));  
    if(nb == -1)  
    {  
        printf("%s\n","set socket error...");
  
        return 0;  
    }  

    if(bind(sock,(struct sockaddr *)&(serv_addr), sizeof(struct sockaddr_in)) == -1)   
    {     
        printf("%s\n","bind error...");
         
        return 0;  
    }  

    int len = sizeof(struct sockaddr_in); 

    char smsg[40] = {0};  

    while(1)  
    {  
        //从广播地址接受消息  

        int ret=recvfrom(sock, smsg, 25, 0, NULL, NULL); 

        if(ret<=0)  
        {  
            printf("%s\n","read error....");

        }  
        else  
        {     
            temp = (struct neighbor*)smsg;

            add_list(temp);

            //printf("%x ", temp->ip);  

            //for(i=0; i<6; ++i)

            //printf("%x\n",temp->mac[i]);
  
        } 
    } 
}
        
int main(int argc ,char *argv[]) 

{   
    keep_time.tv_sec = atol(argv[1]);

    keep_time.tv_usec = atol(argv[2]) * 1000;

    pthread_t a_thread;

    void *thread_result;

    get_buffer_entry();

    neigh_status = (uint8_t*)((uint8_t*)g_pBuffer + NEIGH_STATUS_OFFSET);

    neigh_count = (uint32_t*)((uint8_t*)g_pBuffer + NEIGH_COUNT_OFFSET);

    *neigh_count = 0;

    neigh_data = (neighbor_table*)((uint8_t*)g_pBuffer + NEIGH_DATA_OFFSET);

    signal(SIGALRM, update_neighbor);

    memset(&tick, 0, sizeof(tick)); 

    int res = pthread_mutex_init(&work_mutex,NULL); 

    if (res != 0) 
    {
        perror("Mutex initialization failed");

        exit(1);
    }

    res = pthread_create(&a_thread, NULL, rcv_msg, NULL); 

    if (res != 0) 
    {
        perror("Thread creation failed");

        exit(1);
    }


    res = pthread_join(a_thread, &thread_result);

    if (res != 0) 
    {
        perror("Thread join failed");

        exit(1);
    }

    pthread_mutex_destroy(&work_mutex); 

    return 0;  
}
