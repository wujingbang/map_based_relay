insmod mbr.ko
./netlink_user

ip link set wlp1s0 down
./iw-802.11p dev wlp1s0 set type ocb
ip link set wlp1s0 up
./iw-802.11p dev wlp1s0 ocb join 5850 10MHZ
ip -s link show dev wlan0 
ifconfig wlp1s0 192.168.1.4

sleep 20

rmmod spidev
insmod /home/root/si4463_fpga.ko
iptables -I OUTPUT -d 8.8.0.0/16 -j DROP
iptables -A OUTPUT -p udp --dport 1534 -j DROP
mount -t debugfs none /home/root/d
ifconfig sif0 192.168.2.4
echo 100 > /sys/kernel/debug/si4463/speed_kbps

sleep 20 

if [ $1 == "5.9G" ]
then
./rcv1 &
./sendB &
fi
if [ $1 == "433M" ]
then
./rcv2 &
./sendBB &
fi 
echo 1 > /sys/kernel/debug/mbr/mbr_start
